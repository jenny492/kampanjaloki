function EventList() {
    
    return (
        <>
        </>
    );
}

export default EventList;