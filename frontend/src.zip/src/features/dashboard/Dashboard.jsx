import { Box, Typography } from '@mui/material';

function Dashboard() {

    return (
       <Box className="maincontent">
        
        <Typography variant="h3" gutterBottom>Hallintapaneeli</Typography>
        <Typography>Käyttäjätiedot</Typography>


      </Box>


    )
}

export default Dashboard;